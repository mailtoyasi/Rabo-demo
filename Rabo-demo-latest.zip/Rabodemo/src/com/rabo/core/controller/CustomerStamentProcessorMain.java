package com.rabo.core.controller;

import java.io.File;

import com.rabo.core.processors.CsvCustomerStatementProcessor;
import com.rabo.core.processors.XmlCustomerStatementProcessor;

public class CustomerStamentProcessorMain {

	public static void main(String[] args) throws Exception {
		
		String inputFileName = args[0];
		
		
		System.out.println("Entered file name is:"+inputFileName);
		
		if(inputFileName==null){
			throw new Exception("Please provide valid file name.");
		}
		
		File file = new File(inputFileName);
		
		
		if(file.exists()==false){
			throw new Exception("File is not available.");
		}
		
		
		if(inputFileName.toLowerCase().endsWith("xml")){
			XmlCustomerStatementProcessor xmlCustomerStatementProcessor = new XmlCustomerStatementProcessor();
			
			xmlCustomerStatementProcessor.process(file,file.getParent());
		} else if(inputFileName.toLowerCase().endsWith("csv")){
			CsvCustomerStatementProcessor csvCustomerStatementProcessor = new CsvCustomerStatementProcessor();
			csvCustomerStatementProcessor.process(file,file.getParent());
		}
		
		System.out.println("end of prcoess");  
		
	}
}
