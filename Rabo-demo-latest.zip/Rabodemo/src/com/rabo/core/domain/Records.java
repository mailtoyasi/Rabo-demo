package com.rabo.core.domain;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="records")
public class Records {

	@XmlElement(name="record")
	private List<Record> recordList;

	public List<Record> getRecordList() {
		
		if(null==recordList){
			recordList = new ArrayList<Record>();
		}
		return recordList;
	}

	public void setRecordList(List<Record> recordList) {
		this.recordList = recordList;
	}

	
		
	
}
