package com.rabo.core.processors;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.StringWriter;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.rabo.core.domain.Record;
import com.rabo.core.domain.Records;

public class XmlCustomerStatementProcessor extends AbstractCustomerProcessor {

	@Override
	public List<Record> getRecordsFromInputFile(File file) throws Exception{
		List<Record> recordList = null;

		JAXBContext jaxbContext= JAXBContext.newInstance(Records.class); 

		Unmarshaller unMarshaller = jaxbContext.createUnmarshaller();

		Records records = (Records)unMarshaller.unmarshal(file);

		if(records!=null){
			recordList = records.getRecordList();
		}
		
		System.out.println("Total reord:"+recordList!=null?recordList.size():"0");
		return recordList;
	}

	@Override
	public void writeErrorFile(List<Record> errorRecordList,String errorFilePath) throws Exception {
		Records records =  null;
		StringWriter writter =  null;
		Marshaller  marshaller = null;
		String xmlString = null;
		
		File errorFile =  null;
		BufferedWriter br = null;
		
		try{
			records = new Records();
			writter = new StringWriter();
			
			records.getRecordList().addAll(errorRecordList);

			JAXBContext jaxbContext= JAXBContext.newInstance(Records.class); 
			marshaller = jaxbContext.createMarshaller();
			marshaller.setProperty( Marshaller.JAXB_FORMATTED_OUTPUT, true);
			marshaller.marshal(records,writter);

			xmlString = writter.toString();

			errorFile = new File(errorFilePath+"/error.xml");
			br = new BufferedWriter(new FileWriter(errorFile));
			br.write(xmlString);
		} finally{
			if(br!=null){
				br.close();
				br = null;
			}
			
			writter =  null;
			marshaller = null;
		}
	}


}
