package com.rabo.core.processors;

public class Test {
 public static void main(String[] args) {
	float a = 104.25f;
	float b= 21.25f;
	float d = -14.25f;
	
	System.out.println(a+b);
	System.out.println((a+d));
}
}
