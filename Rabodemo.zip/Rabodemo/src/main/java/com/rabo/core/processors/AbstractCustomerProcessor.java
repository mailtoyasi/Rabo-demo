package com.rabo.core.processors;

import java.io.File;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;

import com.rabo.core.domain.Record;

public abstract class AbstractCustomerProcessor {

	private static final Logger LOGGER = Logger.getLogger(AbstractCustomerProcessor.class);
	
	private final String DUPLICATE_ERR_MSG= "Duplicate record";
	private final String BALANCE_ERR_MSG= "End balance is not correct";

	public void process(File file,String errorFilePath) throws Exception {

		LOGGER.info("process started...");
		
		List<Record> recordList = getRecordsFromInputFile(file);
					
		List<Record> errorRecordList  = validateRecords(recordList);
		
		writeErrorFile(errorRecordList,errorFilePath);
		
		LOGGER.info("process completed...");

	}
	
	public abstract List<Record> getRecordsFromInputFile(File file) throws Exception;

	public abstract void writeErrorFile(List<Record> errorRecordList,String errorFilePath) throws Exception;

	
	public List<Record> validateRecords(List<Record> inputListRecords){
		List<Record> errorRecordList = new ArrayList<Record>();

		boolean isEndBalanceValid = false;

		for(Record record:inputListRecords){

			if(Collections.frequency(inputListRecords,record)>1){
				record.setRejectReason(DUPLICATE_ERR_MSG);
				errorRecordList.add(record);
				continue;
			}

			BigDecimal finalValue = BigDecimal.valueOf((record.getStartBalance() + record.getMutation())).setScale(2, RoundingMode.HALF_UP);
			
			isEndBalanceValid = finalValue.compareTo(BigDecimal.valueOf(record.getEndBalance())) ==0;

			if(!isEndBalanceValid){
				record.setRejectReason(BALANCE_ERR_MSG);
				errorRecordList.add(record);
				continue;
			}
		}

		return errorRecordList;
	}
}
