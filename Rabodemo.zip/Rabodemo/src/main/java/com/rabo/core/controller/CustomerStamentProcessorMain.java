package com.rabo.core.controller;

import java.io.File;

import org.apache.log4j.Logger;

import com.rabo.core.processors.CsvCustomerStatementProcessor;
import com.rabo.core.processors.XmlCustomerStatementProcessor;

public class CustomerStamentProcessorMain {
	
	private static final Logger LOGGER = Logger.getLogger(CustomerStamentProcessorMain.class);

	public static void main(String[] args) throws Exception {
		
		if(args.length==0){
			LOGGER.error("Please provide valid file name.");
			System.exit(0);
		}
		
		String inputFileName = args[0];
		LOGGER.info("Entered file name is:"+inputFileName);
		
		if(inputFileName==null || "".equals(inputFileName)){
			throw new Exception("Please provide valid file name.");
		}
		
		File file = new File(inputFileName);
		String errorFileDirectory = file.getParent();
		
		if(!file.exists()){
			throw new Exception("File is not available.");
		}
		
		
		if(inputFileName.toLowerCase().endsWith("xml")){
			XmlCustomerStatementProcessor xmlCustomerStatementProcessor = new XmlCustomerStatementProcessor();
			
			xmlCustomerStatementProcessor.process(file,errorFileDirectory);
		} else if(inputFileName.toLowerCase().endsWith("csv")){
			CsvCustomerStatementProcessor csvCustomerStatementProcessor = new CsvCustomerStatementProcessor();
			csvCustomerStatementProcessor.process(file,errorFileDirectory);
		}
		
		LOGGER.info("end of prcoess");  
		
	}
}
