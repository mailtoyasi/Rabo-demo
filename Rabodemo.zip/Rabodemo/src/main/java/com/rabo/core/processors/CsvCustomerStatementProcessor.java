package com.rabo.core.processors;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.List;

import org.apache.log4j.Logger;

import com.rabo.core.domain.Record;
import com.rabo.core.domain.Records;

public class CsvCustomerStatementProcessor extends AbstractCustomerProcessor{

	private static final Logger LOGGER = Logger.getLogger(CsvCustomerStatementProcessor.class);
	
	
	@Override
	public List<Record> getRecordsFromInputFile(File file) throws Exception {

		BufferedReader br = null;
		String fileContent = null;
		String fileContentArr [];
		Records records = null;

		try{
			records = new Records();
			br = new BufferedReader(new FileReader(file));


			//Reference,AccountNumber,Description,Start Balance,Mutation,End Balance

			int count = 0;
			while((fileContent=br.readLine())!=null){
				fileContentArr = fileContent.split(",");

				count++;
				if(count!=1) {  // skip header
					Record record = new Record();
					record.setReference(fileContentArr[0]);
					record.setAccountNumber(fileContentArr[1]);
					record.setDescription(fileContentArr[2]);
					record.setStartBalance(fileContentArr[3]!=null?Double.parseDouble(fileContentArr[3]):0.0);
					record.setMutation(fileContentArr[4]!=null?Double.parseDouble(fileContentArr[4]):0.0);
					record.setEndBalance(fileContentArr[5]!=null?Double.parseDouble(fileContentArr[5]):0.0);

					records.getRecordList().add(record);
				}
			}

			LOGGER.info("Total reord:"+records.getRecordList().size());


		} finally{
			if(br!=null){
				br.close();
				br = null;
			}
		}

		return records.getRecordList();
	}

	@Override
	public void writeErrorFile(List<Record> errorRecordList, String errorFilePath) throws Exception {
		File errorFile =  null;
		BufferedWriter br = null;
		StringBuilder sb = null;

		try{
			sb = new StringBuilder();

			for(Record record:errorRecordList){
				sb.append(record).append("\n");
			}
			errorFile = new File(errorFilePath+"/error.csv");
			br = new BufferedWriter(new FileWriter(errorFile));
			br.write(sb.toString());

		} finally{
			if(br!=null){
				br.close();
				br = null;
			}
		}
	}

}
